INSERT INTO Roles (Role_Name) VALUES ('Admin'), ('Librarian'), ('Member');

INSERT INTO Users (First_Name, Last_Name, Email, Phone, Password, Role_ID) 
VALUES ('John', 'Doe', 'john@example.com', '1234567890', 'lkÀÇ"*DjéjkdHQ%%kl', 1);

INSERT INTO Books (Title, Author, ISBN, Category) 
VALUES ('Java Programming', 'James Gosling', '978-0135166307', 'Programming');

INSERT INTO Books_Copies (Book_ID, Status, Location) 
VALUES (1, 'Available', 'Shelf A1');

INSERT INTO Borrow (User_ID, Copy_ID, Borrow_Date, Due_Date) 
VALUES (1, 1, '2025-03-08', '2025-03-15');

INSERT INTO Fines (Borrow_ID, Amount, Paid) 
VALUES (1, 5.00, FALSE);