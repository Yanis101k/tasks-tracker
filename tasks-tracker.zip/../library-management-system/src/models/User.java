package models ; 

public class User {

    private int userId ; 
    private String firstName ; 
    private String lastName ;
    private String email ; 
    private String phone ; 
    private String password ; 
    private int roleId ; // Foreign Key: Links to Roles table

    public User( int userId  , String firstName , String lastName , 
                 String email , String phone , String password  , int roleId ){

        this.userId = userId ; 
        this.firstName = firstName ;
        this.lastName = lastName ;
        this.email = email ; 
        this.phone =  phone ; 
        this.password = password ; 
        this.roleId = roleId ; 

    }

    public int getUserId(){
        return userId ; 
    }

    public void setUserId( int userId ){
        this.userId = userId ; 

    }

    public String getFirstName( ){
        return firstName ; 
    }

    public void setFirstName( String firstName ){
        this.firstName = firstName ; 
    }
    
    public String getLastName( ){
        return lastName ; 
    }

    public void setLastName( String lastName ){
        this.lastName = lastName ; 
    }

    public String getEmail(){
        return email ; 
    }

    public void setEmail( String email ){
        this.email = email ; 
    }
    
    public String getPhone(){
        return phone ; 
    }

    public void setPhone( String phone ){
        this.phone = phone ; 
    }
    public String getPassword( ){
        return password ; 

    }

    public void setPassword( String password ){
        this.password = password ; 
    }

    public int getRoleId( ){
        return roleId ; 
    }

    public void setRoleId( int roleId ){
        this.roleId = roleId ; 
    }
    
    @Override
    public String toString(){
        return String.format(" user ID : %d \t last name : %s \t first name : %s \t phone : %s \t email : %s \t role ID : %d \n",
         userId , lastName , firstName , phone , email , roleId ) ; 

    }

    @Override 
    public boolean equals( Object obj ){
           if( obj == this ){
            return true ; 
           }
           if( obj == null || obj.getClass() != this.getClass() ){
             return false ; 
           }

           User user = (User) obj ; 

           return user.userId == this.userId ; 
    }

    @Override 
    public int hashCode(){
        return this.userId; 
    }

}