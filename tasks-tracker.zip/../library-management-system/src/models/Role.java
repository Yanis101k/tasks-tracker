package models ; 

public class Role {

    private int roleId ; 
    private String roleName ;

    public Role( int roleId , String roleName ){

            this.roleId = roleId ; 
            this.roleName = roleName ;         
    }
    
    public int getRoleId(){
        return roleId ; 
    }

    public void setRoleId( int roleId ){
           this.roleId = roleId ; 
    }

    public String getRoleName(  ){
        return roleName ; 
    }

    public void setRoleName( String roleName ){
        this.roleName = roleName ; 
    }

    @Override
    public String toString(){
        return String.format(" ID : %d \t Name : %d\n", roleId , roleName );
    }

    @Override 
    public boolean equals( Object obj ){

        if( this == obj ){
           return false ; 
        }

        if( obj == null || obj.getClass() != this.getClass() ){
            return false ; 
        }

        Role role = (Role) obj ; 

        return this.roleId == role.roleId ; 


    }

    @Override 
    public int hashCode(){
              return roleId ; 
    }


}