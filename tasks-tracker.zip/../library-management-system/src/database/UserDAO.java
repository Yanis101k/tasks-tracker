package database ; 
import java.sql.* ; 
import models.User ; 
import java.util.List;
import java.util.ArrayList;

public class UserDAO {
    // add a new user to database 
    public static void addUser ( User user ) {

        String query = "INSERT INTO Users (First_Name , Last_Name , Email , Phone , Password , Role_ID) VALUES ( ? , ?  , ? , ? , ? , ? )" ;
        
        try ( Connection conn = DatabaseConnection.getConnection() ;
              PreparedStatement stmt = conn.prepareStatement(query) ){
                stmt.setString(1, user.getFirstName() );
                stmt.setString(2 , user.getLastName() ) ;
                stmt.setString(3 , user.getEmail() ) ;
                stmt.setString(4, user.getPhone());
                stmt.setString(5 , user.getPassword()) ; 
                stmt.setInt(6, user.getRoleId());  
                stmt.executeUpdate() ; 
                System.out.println(" User Added Successfully !");
            
        } catch (SQLException e) {
            
            System.out.println(" Error Adding User !");
            e.printStackTrace();
        }

    }

    // get all users from database 
    public static List<User> getUsers(){

        List<User> users = new ArrayList<>() ; 

        String query = "SELECT * FROM Users" ; 
        
        try (Connection conn = DatabaseConnection.getConnection() ; 
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery() ){

                while(rs.next() ){
                    users.add(new User(rs.getInt("User_ID") , rs.getString("First_Name") , rs.getString("Last_Name") ,
                                       rs.getString("Email") , rs.getString("Phone") , rs.getString("Password"), 
                                       rs.getInt("Role_ID") )) ; 
                }

        } catch( SQLException e ){

            System.out.println(" Error Fetching Users!");
            e.printStackTrace();

        }

        return users ; 
        
    } 
   // update user  in database 
    public static void updateUser( int userId , User newUser ){
        String query = "UPDATE Users SET First_Name = ? , Last_Name = ? ," +
                       " Email = ? , Phone = ? , Password = ? , Role_ID = ? WHERE User_ID = ?" ; 

        try ( Connection conn = DatabaseConnection.getConnection();
              PreparedStatement stmt = conn.prepareStatement(query)){
                stmt.setString( 1 , newUser.getFirstName() );
                stmt.setString(2, newUser.getLastName());
                stmt.setString(3, newUser.getEmail());
                stmt.setString(4, newUser.getPhone());
                stmt.setString(5, newUser.getPassword());
                stmt.setInt(6, newUser.getRoleId());
                stmt.setInt(7 , userId);
                stmt.executeUpdate() ; 
                System.out.println(" User Updated Successfully!") ; 
            
        } catch (SQLException e) {
            // TODO: handle exception
            System.out.println("Error Updating User!");
            e.printStackTrace() ; 
            
        }
    }
    
    // delet user from database 
    public static void deletUser( int userId ){

        String query = "DELETE FROM Users WHERE User_ID = ? " ; 

        try ( Connection conn = DatabaseConnection.getConnection() ; 
              PreparedStatement stmt = conn.prepareStatement(query) ){
              stmt.setInt( 1,userId ) ; 
              stmt.executeUpdate(); 
              System.out.println(" User Deleted Successfully! ");
        } catch ( SQLException e ){
            System.out.println(" Error Deleting User!"); 
            e.printStackTrace(); 
        }


    }

    // delet all users in database 

    public static void deletAllUsers(){
        String query = "DELETE FROM Users" ;
        
        try( Connection conn = DatabaseConnection.getConnection() ;
             PreparedStatement stmt = conn.prepareStatement(query)  ){
                stmt.executeUpdate() ; 
                System.out.println(" All Users Deleted Successfully!");

        } catch( SQLException e ){
             System.out.println(" Error Deleting All Users !") ; 
             e.printStackTrace();
        }
    }

    public static User getUserByEmail( String email ){
        String query = "SELECT * FROM Users WHERE Email = ?" ; 
        User user = null ;
        
        try ( Connection conn = DatabaseConnection.getConnection() ;
              PreparedStatement stmt = conn.prepareStatement(query) ; ){

                stmt.setString(1, email );

                ResultSet rs = stmt.executeQuery() ; 

                if( rs.next() ){
                    user = new User(rs.getInt("User_ID"),
                                    rs.getString("First_Name"), 
                                    rs.getString("Last_Name"), 
                                    rs.getString("Email") , 
                                    rs.getString("Phone"), 
                                    rs.getString("Password"),
                                    rs.getInt("Role_ID") ) ; 

                }

                
            
        } catch (SQLException e) {
                                System.out.println(" Error Fetching User By Email!");
                                e.printStackTrace();
        }
        return user ; 
    }

    public static void main( String[] args ){

        
        /*UserDAO.addUser( new User(  0 , "Yanis" , "Kaced" , "yaniskaced41@gmail.com" , "+447557874691" , "jk@èaa1kauk" , 11) );
        UserDAO.addUser( new User(  0 , "Kenza" , "Hassam" , "kenzahassam11@gmail.com" , "+447059074631" , "dsh8qkl-#kds=" , 12) );
        UserDAO.addUser( new User(  0 , "Ghani" , "Belekacemi" , "ghanibelei19@gmail.com" , "+4479544691" , "sdgdsè-&;AYà" , 13));

        List<User> users = getUsers() ; 

        for( User user : users ){
            System.out.println("User: " + user.getUserId() + " - " + user.getFirstName() + " " + user.getLastName());
        }*/

        UserDAO.updateUser(7, new User(  0 , "Ghani" , "Belekacemi" , "ghanibelei19@gmail.com" , "+4479544691" , "sdgdsè-&;AYà" , 11));
        UserDAO.updateUser(6, new User(  0 , "Kenza" , "Hassam" , "kenzahassam11@gmail.com" , "+447059074631" , "dsh8qkl-#kds=" , 11) );
        
        }
}