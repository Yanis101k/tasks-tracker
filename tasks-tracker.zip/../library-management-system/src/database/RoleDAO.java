package database ; 

import models.Role ; 
import java.sql.*;
import java.util.ArrayList;
import java.util.List ;  

public class RoleDAO{

    // Add a new role to data base  

    public static void addRole( String roleName ){
        String query = "INSERT INTO Roles (Role_Name) VALUES (?)" ;
        
        try ( Connection conn = DatabaseConnection.getConnection() ; 
              PreparedStatement stmt = conn.prepareStatement(query) ) {
                stmt.setString(1, roleName );
                stmt.executeUpdate() ; 
                System.out.println(" Role Added Successfully : " + roleName);
              }catch( SQLException e ){
                System.out.println(" Error Adding Role! ");
                e.printStackTrace();

              }
    }
    
    // get all roles from data base 
    public static List<Role> getRoles() {
        List<Role> roles = new ArrayList<>() ;
        String query = "SELECT * FROM Roles";
        
        try ( Connection conn = DatabaseConnection.getConnection() ; 
              PreparedStatement stmt = conn.prepareStatement(query) ; 
              ResultSet rs = stmt.executeQuery()){

                while( rs.next()) {
                    roles.add( new Role( rs.getInt("Role_ID") , rs.getString("Role_Name"))) ; 
                }

        }catch( SQLException e ){
            System.out.println(" Error Fetching Roles!");
            e.printStackTrace();

        }

        return roles ; 
    }

    // update a role 
    public static void updateRole( int roleId , String newName ){
        String query = "UPDATE Roles SET Role_Name = ? WHERE Role_ID = ?";
        try ( Connection conn = DatabaseConnection.getConnection();
              PreparedStatement stmt = conn.prepareStatement(query)){

                stmt.setString(1, newName ) ;
                stmt.setInt(2,roleId) ;  
                stmt.executeUpdate() ; 
                System.out.println(" Role Updated Successfully!");

        } catch( SQLException e ){
              System.out.println(" Error Updating Role!");
              e.printStackTrace();
        }
    }

    // delet role 

    public static void deletRole( int roleId ){
        String query = "DELETE FROM Roles WHERE Role_ID = ?";
        
        try ( Connection conn = DatabaseConnection.getConnection();
              PreparedStatement stmt = conn.prepareStatement(query) ){
              stmt.setInt(1, roleId);
              stmt.executeUpdate() ; 
              System.out.println(" Role Deleted Successfully!");
            
        } catch (SQLException e) {
            
            System.out.println(" Error Deleting Role!");
            e.printStackTrace();

        }
    }
     // delet all roles 
     public static void deleteAllRoles() {
        String query = "DELETE FROM Roles";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {   

            stmt.executeUpdate();
            System.out.println(" All Roles Deleted Successfully!");

        } catch (SQLException e) {
            System.out.println(" Error Deleting All Roles!");
            e.printStackTrace();
        }
    }
    // Test the CRUD methods 
    public static void main( String[] args ){

        
        

        addRole("Admin");
        addRole("Librarian");
        addRole("Member");
        

        
        

        /*updateRole( 8 , "Super Admin" );
        List<Role> roles = getRoles(); 
        
        for( Role r : roles ){

            System.out.println(" Role : " + r.getRoleId() + "\t Role Name : " + r.getRoleName());

        }
            
        
        //deletRole(9);
        //deletRole(10);
        

        List<Role> roles = getRoles(); 

        for( Role r : roles ){
            System.out.println(" Role ID : " + r.getRoleId() + " Role Name : " + r.getRoleName() );
        }
        */

        
            

    }
}