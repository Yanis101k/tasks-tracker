package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/LibraryManagement";
    private static final String USER = "library_admin";  
    private static final String PASSWORD = "ag15#Sh@=K4i=!0*B"; 

    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println(" Database Connected Successfully!");
        } catch (ClassNotFoundException e) {
            System.out.println(" JDBC Driver Not Found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println(" Database Connection Failed!");
            e.printStackTrace();
        }
        return connection;
    }

    public static void main(String[] args) {
        getConnection();  // Test connection
    }
}
